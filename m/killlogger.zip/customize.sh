ui_print " "
  ui_print "*******************************"
  ui_print "*    Magisk Module KillLogger++     *"
  ui_print "*               Version 1.9                        *"
  ui_print "*******************************"
  ui_print " "


ui_print " Внесение в build.prop строчек "
ui_print " ............................."
ui_print " ............................."

ui_print " Отключение демонов в system , vendor"
ui_print " .................................."
ui_print " .................................."

ui_print " Очистка уже созданных логов  в data , dev , sys... "
ui_print " ................................."


ui_print " Готово логи отключены ! "
ui_print " Пожалуйста Перезагрузите устройство для применения эффекта "


ui_print " Love by mrfrost475 "
ui_print "Special Thanks
- mrfrost475
- huan0526
- Zillot
- Krapkert
- Archeix"

#Disabling Scheduler statistics

echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats

#Minimize Dropbox Logs to 1

content insert --uri content://settings/global --bind name:s:dropbox_max_files --bind value:i:1 
settings put global dropbox_max_files 1

#Fstrim partitions
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload