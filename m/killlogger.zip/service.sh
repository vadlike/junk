#Delete Logs
rm -rf /data/anr/*
rm -rf /dev/log/*
rm -rf /data/tombstones/*
rm -rf /data/log_other_mode/*
rm -rf /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -rf /data/log/*
rm -rf /sys/kernel/debug/*
rm -rf /data/local/tmp*

#Delete Thumbnails

rm -rf /data/media/0/DCIM/.thumbnails
rm -rf /data/media/0/Pictures/.thumbnails
rm -rf /data/media/0/Music/.thumbnails
rm -rf /data/media/0/Movies/.thumbnails

#Delete MTK Logs
rm -rf /data/media/0/mtklog

#Delete MIUI Logs
rm -rf /data/media/0/MIUI/Gallery
rm -rf /data/media/0/MIUI/.debug_log
rm -rf /data/media/0/MIUI/BugReportCache
