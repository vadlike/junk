#Enable DopBox Logging
content insert --uri content://settings/global --bind name:s:dropbox_max_files --bind value:i:250 
settings put global dropbox_max_files 250

#Enable Scheduler statistics
echo "1" > /sys/block/mmcblk0/queue/iostats
echo "1" > /sys/block/mmcblk1/queue/iostats