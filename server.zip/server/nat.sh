#!/bin/bash



. /etc/server/func.nat



case ${per[0]} in
     stop) echo 'Останавливаем файрвол и разрешаем всё';
	   exit 0;;
  systemd) case ${per[0]} in
	     del) systemctl disable nat.service;
		  rm -f /etc/systemd/system/nat.service;
		  exit 0;;
	       *) ln -s /etc/server/nat.service /etc/systemd/system/nat.service;
		  systemctl enable nat.service;;
	   esac;;
esac

cd /root && nohup java -jar Ultima-1.0-SNAPSHOT.jar -sp 10000 -ep 10020 -io 125 -s 15000 -x 16000 >> run.log 2>&1 &